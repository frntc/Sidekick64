if you place one >name<.logo for a >name<.crt is will be displayed on the OLED screen
Format: raw image, 8 bit per pixel, resolution 128x64
