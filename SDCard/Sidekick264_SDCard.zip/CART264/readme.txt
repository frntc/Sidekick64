Alpharay and Pet's Rescue have been kindly ported and provided for Sidekick264 by Mad^BKN (both require a Plus/4 or C16 with 64k RAM).

Note that these versions do not support save games.

Please support the development of such cool games and consider buying them at http://www.psytronik.net.

Proceeds from both games are donated to charity!

Credits for Alpharay:
Coded by Stefan Mader (Mad)
Additional code by Bubis
Graphics by KiCHY & Nero
Additional graphics by Lu Isa & Noud
Music by 5tarbuck
Cover Art by Trevor Storey
A 2019 Puls4r Production

Credits for Pet's Rescue:
Coded by Stefan Mader (Mad)
Graphics by KiCHY & Luca
Additional gfx by Nero & Carrion
Music by Luca, Degauss & 5tarbuck
Cover Art by Trevor Storey
A 2018 +4 All Stars Production

